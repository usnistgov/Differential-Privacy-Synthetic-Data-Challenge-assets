# NIST: Differential Privacy Synthetic Data Challenge
## Competitor Pack
### Content

1.  Challenge dataset:

    1.  [`data/fire-data.csv`](data/fire-data.csv) - The main dataset to be
        privatized.

    2.  [`data/fire-data-specs.json`](data/fire-data-specs.json) - The important
        part of the dataset's data dictionary.

    3.  [`data/fire-data-specs-mapping.json`](data/fire-data-specs-mapping.json)
        \- An auxiliary part of the dataset's data dictionary (not required for
        the challenge scope).

2.  Sample Python scripts:

    1.  [`scripts/simple-dp.py`](scripts/simple-dp.py) - A sample naive
        implementation of a simple differential data privacy algorithm.

    2.  [`scripts/generate-submission.py`](scripts/generate-submission.py) -
        An auxiliary script for preparation of submissions into Topcoder system.

    3.  [`scripts/ground-truth-generator.py`](scripts/ground-truth-generator.py)
        \- The stochastic ground-truth generator.

    4.  [`scripts/test-scoring.py`](scripts/test-scoring.py) - A Python
        implementation of the core scoring logic.

### Challenge Dataset

**The dataset to be privatized** in this challenge is provided in CSV format:
[`data/fire-data.csv`](data/fire-data.csv). It is a subset of
[San Francisco's Fire Deparment Call for Service dataset](https://data.sfgov.org/Public-Safety/Fire-Department-Calls-for-Service/nuek-vuh3),
reduced to data for the year 2017 only. For the sake of simplicity all original
data values were converted to numeric formats in the following ways:

- Categorical values (string literals) were replaced by consequitive integer
  numbers from 0 (inclusive) to _N_ (exclusive), where _N_ is the total number of
  possible values. The columns containing such data are denoted by `enum` type
  in the data dictionary JSON file
  [`data/fire-data-specs.json`](`data/fire-data-specs.json), where _N_ values
  are also given in the _count_ fields.

  The additional JSON document
  [`data/fire-data-specs-mapping.json`](data/fire-data-specs-mapping.json)
  provides, for columns with categorical values, the mappings between resulting
  integer values and the original data. Though, this information is provided for
  curiousity, and it is not necessary for the challenge purposes.

- Date/time values were parsed and converted into integer Unix timestamps
  (number of seconds from 00:00:00 UTC, January 1, 1970). Such columns, along
  with originally integer columns, are denoted by `integer` type in the data
  dictionary file. The range of their possible values is given by _min_ and
  _max_ fields in there (both inclusive). The additional _optional_ (boolean)
  field tells whether empty values might be present in corresponding columns.

- The column with geographical coordinates was split into two separate columns
  containing real numbers for lattitude and longitude. Each of resulting columns
  is denoted by `float` type in the data dictionary, with _min_ and _max_
  values provided.

Data columns in the [`data/fire-data.csv`](data/fire-data.csv) dataset were
sorted in such way that sizes of value domains for each column increase from
the first two the last column; i.e. the first and second columns contain
categorical data with two possible values; 3-rd column contains categorical
data with 5 possible values; etc. Numerical (both integer and float) columns
are placed along with the categorical data columns containing 100 possible
values.

---

**The data dictionary** is provided in JSON format
[data/fire-data-specs.json](data/fire-data-specs.json). As explained above,
for each column it provides data type in _type_ fields. There are three cases:

- `enum` type denotes columns with categorical data. The _count_ field provides
  the number of possible values in each of such columns; and the possible values
  themselves are from 0 (inclusive) to _N_ (exclusive).

- `integer` and `float` types denote columns with integer and float values. In
  both cases, the dictionary provides their _min_ and _max_ values (both
  inclusive); along with _optional_ boolean field, which tells whether the value
  is optional (may be empty). For the columns with _optional_ equal `false`, each
  record in the dataset must have a numeric value; while for the columns with
  _optional_ field equal `true` a record may have either numeric value, or to
  be empty.

**The auxiliary part of the data dictionary**
[`data/fire-data-specs-mapping.json`](data/fire-data-specs-mapping.json) is
provided for curiosity, and it is not necessary for the purpose of this
challenge. It contains mappings between integer codes and original literal
values of categorical (`enum`) columns.

### Sample Python Scripts

Four Python 3 scripts are provided in the `script` folder of this competitor
pack. They were tested on Ubuntu 18.04, and might require slight modifications
to work on MacOS or Windows machines. There is dependency on `numpy` package,
you can run install it with `$ pip3 install numpy` command.

**A sample naive implementation of a simple _epsilon_ differential data privacy**
algorithm is provided by [`scripts/simple-dp.py`](scripts/simple-dp.py).
Example usage is (all paths below are relative to the root of competitor
pack):

`$ ./scripts/simple-dp.py data/fire-data.csv privatized-dataset.csv data/fire-data-specs.json 0.3 3`

where 0.3 is the _epsilon_ value and 3 is the number of data columns to handle
(see the challenge scoring details in the challenge rules). 3 is the minimal
valid number of columns to submit for the scoring. This algorithm
assumes _delta_ equal to zero.

---

**An auxiliary script for preparation of Topcoder submission** is provided in
[`scripts/generate-submission.py`](scripts/generate-submission.py). For a
differential data privacy algorithm, exposed via the same command line interface
as the sample algorithm above, it:

- Runs the algorithm, on the specified number of columns, three times with
  _epsilon_ values 10.0; 1.0; and 0.1, required by the challenge rules;

- Checks that resulting output files, `10_0.csv`, `1_0.csv`, and `0_1.csv`
  satisfy the size limit (100 Mb max per file);

- Pack output files into ZIP archive with the specified name.

Resulting ZIP file should be uploaded to a file hosting, supporting direct
download URLs. For example, Google.Drive supports them, if you get share link
and replace its `open` piece by `uc`, like so:

`https://drive.google.com/uc?id=1MUMH0IZ3-zgfLYloFXvOrhA4EpKgEBrl`

The resulting URL should be wrapped in the following piece of Java code, which
you submit into Topcoder system:

```java
class NistDp1 {
  public String getAnswerUrl() {
    return "https://drive.google.com/uc?id=1MUMH0IZ3-zgfLYloFXvOrhA4EpKgEBrl";
  }
}
```

Run the script as 

`$ ./scripts/generate-submission.py scripts/simple-dp.py data/fire-data.csv output.zip data/fire-data-specs.json 5`

where the second argument is the command to run your algorithm from the command
line; and 5 is the number of columns to handle, which will be passed down into
your algorithm.

---

For local testing you are provided with
**the stochastic ground-truth generator**
[`scripts/ground-truth-generator.py`](scripts/ground-truth-generator.py).
Each run of the generator produces a randomized set of scoring tests to feed
into the _test scoring_ script below. Similarly generated sets of scoring tests
are used for provisional and system scoring of the challenge. Run the script as:

`$ ./scripts/ground-truth-generator.py data/fire-data.csv data/fire-data-specs.json sample-ground-truth.csv`

A single CSV file, containing a privatized dataset (or its subset, consisting of
_N_ first columns), can be fed together with the generated ground truth file,
into the local **test scoring script**
[`scripts/test-scoring.py`](scripts/test-scoring.py), in the following manner:

`$ ./scripts/test-scoring.py privatized-dataset.csv data/fire-data-specs.json sample-ground-truth.csv`

The scoring script detects the number of columns automatically, and returns the
score in the range from 0 to 1 000 000 (corresponds to a fully processed dataset,
that ideally conserves records distributions).

The minimal valid number of columns is 3, and it will give a score in
[0; 33 333] range. Every additional column adds 33 000 to the maximum possible
score (each ground truth contains 30 test cases).

During the provisional scoring, the scores from three generated datasets
(for _epsilon_ = 10.0; 1.0; 0.1) are averaged.

See challenge rules for detailed information on the scoring procedure.
