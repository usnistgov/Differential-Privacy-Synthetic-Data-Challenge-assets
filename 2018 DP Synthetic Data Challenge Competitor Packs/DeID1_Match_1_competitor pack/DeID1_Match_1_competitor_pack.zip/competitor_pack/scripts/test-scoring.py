#!/usr/bin/python3

################################################################################
# POC version of the scoring code.

import csv
import json
import sys

NUM_BUCKETS = 100

# The code will print log message to console when processing each n-th row
# specified here.
NUM_ROWS_BETWEEN_LOG_MESSAGES = 250000

################################################################################
# Initialization.

print('Intitialization...')

# Reads command-line arguments:
# - Solution
# - Data Specs
# - Ground truth

_, inDataFilename, inDataSpecsFilename, inGroundTruth = sys.argv

# Opens files.

inData = csv.reader(open(inDataFilename, newline=''), dialect='excel')
inGT = csv.reader(open(inGroundTruth, newline=''), dialect='excel')
inDataSpecs = json.load(open(inDataSpecsFilename))
dataHeader = next(inData)

# Loads ground truth data

counts = {}
columnSets = []

for row in inGT:
  if row[0] == '@NEWCASE!':
    testId = len(columnSets)
    counts[testId] = {}
    columnSets.append([int(row[1]), int(row[2]), int(row[3])])
  else:
    test = counts[testId]
    key1 = row[0]
    key2 = row[1]
    key3 = row[2]
    count = row[3]
    if key1 != '': key1 = int(key1)
    if key2 != '': key2 = int(key2)
    if key3 != '': key3 = int(key3)
    if count != '': float(count)
    if key1 not in test: test[key1] = {}
    if key2 not in test[key1]: test[key1][key2] = {}
    if key3 not in test[key1][key2]: test[key1][key2][key3] = count

################################################################################
# Getting stats from the submission.

print('Collecting stats from the solution...')

solution = {}

def countRow(row, bucket, cols, depth):
  value = row[cols[depth]]
  d = inDataSpecs[dataHeader[cols[depth]]]
  if d['type'] == 'enum':
    bucketId = int(value)
    if bucketId < 0 or bucketId >= d['count']: bucketId = 'outrange'
  elif value == '': bucketId = ''
  else: # integer or float
    bucketSize = 1.0001 * float(d['max'] - d['min']) / NUM_BUCKETS
    bucketId = int((float(value) - d['min']) / bucketSize)
    if bucketId < 0 or bucketId >= NUM_BUCKETS: bucketId = 'outrange'
  
  # bucketId = 'outrange'

  if depth == 2: # We are at leaf > just increment the counter.
    if bucketId in bucket: bucket[bucketId] += 1
    else: bucket[bucketId] = 1
  else:
    if bucketId not in bucket: bucket[bucketId] = {}
    bucket[bucketId] = countRow(row, bucket[bucketId], cols, 1 + depth)

  return bucket

rowIndex = 0
for row in inData:
  # Logging
  rowIndex += 1
  if rowIndex % NUM_ROWS_BETWEEN_LOG_MESSAGES == 0:
    print(f'{rowIndex / 1000 :12}k rows processed')

  # if rowIndex == 10000: break

  # Count the row for each ground truth chunk
  for index in range(len(columnSets)):
    if index not in solution: solution[index] = {}
    cset = columnSets[index]
    if cset[2] < len(row) and cset[1] < len(row) and cset[0] < len(row):
      solution[index] = countRow(row, solution[index], cset, 0)
    else: solution[index] = { 'outrange': { 'outrange': { 'outrange': rowIndex } } }

################################################################################
# Scoring.

print('Scoring...')

# print(counts);
# del counts[1]
# del solution[1]

score = 2 * len(counts.keys())

# TODO: Some normalization of the score is needed here, to keep it in the range
# from 0 to 1 000 000.
for testId in solution:
  for key1 in solution[testId]:
    for key2 in solution[testId][key1]:
      for key3 in solution[testId][key1][key2]:
        v1 = float(solution[testId][key1][key2][key3]) / rowIndex
        if key1 in counts[testId] and key2 in counts[testId][key1] and key3 in counts[testId][key1][key2]:
          v2 = float(counts[testId][key1][key2][key3])
          del counts[testId][key1][key2][key3]
        else: v2 = 0
        score -= abs(v2 - v1)

# And visiting all 
for testId in counts:
  for key1 in counts[testId]:
    for key2 in counts[testId][key1]:
      for key3 in counts[testId][key1][key2]:
        v1 = float(counts[testId][key1][key2][key3])
        score -= abs(v1)

score *= 1000000.0 / 2 / len(counts.keys())

print(f'SCORE = {score}')
